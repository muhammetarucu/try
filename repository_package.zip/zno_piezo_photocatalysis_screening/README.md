# Uncertainty-aware ML screening of doped ZnO for piezo-photocatalysis: code and data
Supporting material for: M. Arucu, *Machine Learning-Assisted Screening of Doped ZnO for Piezo-Photocatalytic Applications: Combining Public DFT Databases with Device-Level FEM Simulation* (Materials Today Communications, MTCOMM-D-26-04914).
Persistent identifier: **[ZENODO DOI]**  |  Licence: **[TO BE CHOSEN BY THE AUTHOR; e.g. MIT for code, CC BY 4.0 for data]**

## Layout
| Path | Content |
|---|---|
| `notebooks/Master_v4_Revision.ipynb` | production ensembles (formula-grouped 60/20/20), split-conformal intervals, scissor anchor, candidate generation, figure of merit, Monte-Carlo propagation; writes `screening_results_v4.csv` |
| `notebooks/Revision2_Colab_Analyses.ipynb` | metrics (global and 1-5 eV oxide window), conformal variants, Monte-Carlo sensitivity, fine concentration grid, element-level control, kernel-ridge replication, family-internal validation, Fig. 2, `provenance.json` |
| `notebooks/ZnO_FEM_Nanopillar_Bolum2_v4.ipynb` | coupled piezoelectric FEM (scikit-fem) and the independent SfePy cross-check |
| `notebooks/DFT_Dogrulama_QE_v2.ipynb`, `qe/` | Quantum ESPRESSO supercell calculations (see `qe/README.md`) |
| `scripts/a1_enrichment.py`, `a1b_pairs.py` | element enrichment statistics, permutation and element-pair tests, correlated-error Monte-Carlo (Table S1) |
| `scripts/a2_fem.py`, `fem_core.py`, `a2b_fig9.py` | tensor-scaling sweeps (e-scaling, d-scaling, kappa, aspect ratio), mesh convergence, Fig. 9 (Tables S6-S7) |
| `scripts/a3_additivity.py` | co-doping additivity (Fig. 13) |
| `scripts/a4_misc.py`, `a4b_magpie_types.py` | Ce electronegativity sensitivity; Magpie descriptor displacement under dilute substitution |
| `scripts/figs_final.py` | Fig. 1, Fig. 7, Fig. 11 |
| `data/screening_results_v4.csv` | results for all 294 compositions (point estimates, conformal and Monte-Carlo intervals) |
| `data/results_tables/` | outputs of the scripts above |
| `data/colab_outputs/` | outputs of `Revision2_Colab_Analyses.ipynb` (copy from Drive, see README there) |
| `figures/` | final manuscript figures |

## Data and environment
- JARVIS-DFT `dft_3d` (September 2025 release), 93,902 entries; MD5 of the sorted `jid` list: `d4505899d0c21a6d1046d9b176d105ec` (see `provenance.json`). Targets: `mbj_bandgap` (21,559) and `dfpt_piezo_max_dij` with OptB88vdW gap > 0.1 eV and 0 <= d_ij < 2000 pC/N (3,019).
- Software versions: `requirements.txt` and `provenance.json`. Random seeds: data splits 42; ensemble members 0-4; Monte-Carlo 0 (500 draws).
- Re-running `Revision2_Colab_Analyses.ipynb` with these versions reproduces the `screening_results_v4.csv` predictions to within 1e-6 eV (gap) and 5e-8 relative (enhancement); the notebook prints this check.
- Scripts use paths relative to `scripts/`; run them from that directory (e.g. `python a1_enrichment.py`).

## Known limitations of this package
- The original QE run directory was not retained (see `qe/README.md`).
- Older exploratory notebooks of the project (earlier model versions) are intentionally not included; the manuscript results derive only from the files listed above.
