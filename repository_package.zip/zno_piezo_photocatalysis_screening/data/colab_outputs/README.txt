Copy here the contents of the Drive folder MyDrive/ZnO_makale/revision3/ written by notebooks/Revision2_Colab_Analyses.ipynb:
  metrics_table.csv, conformal_variants.csv, mc_sensitivity.csv, fine_grid.csv, element_lookup.csv, smooth_model.csv,
  family_holdout.csv, provenance.json, revision3_results.json   (magpie_cache.pkl is large; it can be omitted - it is regenerated)
and the figures figs/Fig2_model_quality.png and figs/Fig_fine_grid.png (to ../figures/).
