import numpy as np, scipy.sparse as sp, json, time
from scipy.optimize import curve_fit
from skfem import (MeshHex, Basis, FacetBasis, ElementHex1, ElementVector, BilinearForm, LinearForm, asm, condense, solve)
from skfem.helpers import sym_grad, grad, dot, ddot
EPS0 = 8.8541878128e-12
c11,c12,c13,c33,c44 = 209.7e9,121.1e9,105.1e9,210.9e9,42.5e9; c66 = 0.5*(c11-c12)
Cv = np.array([[c11,c12,c13,0,0,0],[c12,c11,c13,0,0,0],[c13,c13,c33,0,0,0],[0,0,0,c44,0,0],[0,0,0,0,c44,0],[0,0,0,0,0,c66]])
voigt = [(0,0),(1,1),(2,2),(1,2),(0,2),(0,1)]
C4 = np.zeros((3,3,3,3))
for I,(i,j) in enumerate(voigt):
    for J,(k,l) in enumerate(voigt): C4[i,j,k,l]=C4[j,i,k,l]=C4[i,j,l,k]=C4[j,i,l,k]=Cv[I,J]
e_mat = np.zeros((3,6)); e_mat[2,0]=e_mat[2,1]=-0.57; e_mat[2,2]=1.32; e_mat[0,4]=e_mat[1,3]=-0.48
kap0 = np.diag([7.77,7.77,8.91])*EPS0
S = np.linalg.inv(Cv)
Gam = e_mat @ S @ e_mat.T                      # e s e^T  (3x3)
epsT0 = kap0 + Gam                              # serbest-gerilme geçirgenliği
def e3_of(em):
    t = np.zeros((3,3,3))
    for k in range(3):
        for J,(i,j) in enumerate(voigt): t[k,i,j]=t[k,j,i]=em[k,J]
    return t
# --- analitik büyüklükler ---
k2_33 = Gam[2,2]/kap0[2,2]
w = np.linalg.eigvalsh(np.linalg.inv(np.linalg.cholesky(epsT0)) @ Gam @ np.linalg.inv(np.linalg.cholesky(epsT0)).T)
lam_adm = 1/np.sqrt(w.max())
print(f'e s e^T / κ^S (33) = {k2_33:.3f}   k_T² (maks) = {w.max():.3f}   d-ölçekleme için fiziksel sınır λ_adm = {lam_adm:.2f}')

class Geo:
    def __init__(s, L, n_xy, n_z, R=100e-9):
        s.L = L; s.side = R*np.sqrt(np.pi)
        s.mesh = MeshHex.init_tensor(np.linspace(0,s.side,n_xy+1), np.linspace(0,s.side,n_xy+1), np.linspace(0,L,n_z+1))
        s.bu = Basis(s.mesh, ElementVector(ElementHex1())); s.bp = Basis(s.mesh, ElementHex1())
        @BilinearForm
        def stiff(u,v,w): return ddot(sym_grad(v), np.einsum('ijkl,kl...->ij...', C4, sym_grad(u)))
        s.K = asm(stiff, s.bu)
        e3 = e3_of(e_mat)
        @BilinearForm
        def coup(u,q,w): return dot(grad(q), np.einsum('kij,ij...->k...', e3, sym_grad(u)))
        B = asm(coup, s.bu, s.bp)
        s.nu = s.K.shape[0]; s.np_ = s.bp.N
        s.B = B.T if B.shape[0]==s.np_ else B       # (nu x np)
        fb = FacetBasis(s.mesh, s.bu.elem, facets=s.mesh.facets_satisfying(lambda x: x[2] > L*(1-1e-6)))
        @LinearForm
        def trac(v,w): return -1.0e6*v[2]
        s.f = asm(trac, fb)
        s.D = np.concatenate([s.bu.get_dofs(lambda x: x[2] < L*1e-6).all(), s.nu + s.bp.get_dofs(lambda x: x[2] < L*1e-6).all()])
        z = s.bp.doflocs[2]; s.top = np.where(np.abs(z - z.max()) < L*1e-6)[0]
        s.Mcache = {}
    def M(s, kap):
        key = tuple(np.round(kap.ravel()/EPS0, 9))
        if key not in s.Mcache:
            @BilinearForm
            def diel(p,q,w): return dot(grad(q), np.einsum('ij,j...->i...', kap, grad(p)))
            s.Mcache[key] = asm(diel, s.bp)
        return s.Mcache[key]
    def phi_top(s, lam, mode='e', kscale=1.0, cscale=1.0):
        if mode == 'e': kap = kscale*kap0
        else:
            kap = epsT0 - lam**2*Gam
            if np.linalg.eigvalsh(kap).min() <= 0: return np.nan
        A = sp.bmat([[cscale*s.K, lam*s.B],[lam*s.B.T, -s.M(kap)]], format='csr')
        b = np.concatenate([s.f, np.zeros(s.np_)])
        x = solve(*condense(A, b, D=s.D))
        return abs(float(x[s.nu:][s.top].mean()))*1e3          # mV

def mk(LD, nxy=6): return Geo(LD*200e-9, nxy, max(12, int(round(4*LD))))
g5 = mk(5.0); base = g5.phi_top(1.0); print(f'taban (L/D=5, λ=1): {base:.2f} mV   [manuscript: 115.1]')

k2f = lambda lam, k2: lam*(1+k2)/(1+lam**2*k2)
def fit(lams, ratios):
    ok = np.isfinite(ratios); p,_ = curve_fit(k2f, np.array(lams)[ok], np.array(ratios)[ok], p0=[0.27], bounds=(1e-4, 5)); return float(p[0])
lams = np.round(np.r_[np.arange(1.0, 5.01, 0.25), 2.98, 3.21, 3.33], 3); lams.sort()
OUT = {'k2_33_clamped': float(k2_33), 'kT2_max': float(w.max()), 'lambda_admissible_dscaling': float(lam_adm), 'base_mV': base}
print('\nλ-taraması (L/D=5), oranlar φ(λ)/φ(1):')
sweeps = {}
t0 = time.time()
for name, kw in [('e-ölçekleme (taban)', dict(mode='e')), ('d-ölçekleme (ε^T,c sabit)', dict(mode='d')),
                 ('e-ölçekleme κ×0.7', dict(mode='e', kscale=0.7)), ('e-ölçekleme κ×1.3', dict(mode='e', kscale=1.3)),
                 ('e-ölçekleme c×0.7', dict(mode='e', cscale=0.7)), ('e-ölçekleme c×1.3', dict(mode='e', cscale=1.3))]:
    ph = np.array([g5.phi_top(l, **kw) for l in lams]); r0 = g5.phi_top(1.0, **kw)
    sweeps[name] = dict(lam=lams.tolist(), mV=ph.tolist(), ratio=(ph/r0).tolist(), ref_mV=r0)
    if kw['mode']=='e':
        k2 = fit(lams, ph/r0); sweeps[name].update(k2_eff=k2, lam_opt=1/np.sqrt(k2), ratio_max=k2f(1/np.sqrt(k2), k2))
        print(f'  {name:28s} k²_eff={k2:.3f}  λ_opt={1/np.sqrt(k2):.2f}  maks oran={k2f(1/np.sqrt(k2),k2):.3f}   φ(1)={r0:.1f} mV')
    else:
        i = [j for j,l in enumerate(lams) if abs(l-2.0)<1e-9][0]
        print(f'  {name:28s} λ=2 oranı={ph[i]/r0:.3f}  (λ>{lam_adm:.2f} → κ^S<0, fiziksel değil)')
print(f'  (süre {time.time()-t0:.0f} s)')
for l in (2.98, 3.21, 3.33):
    j = [i for i,x in enumerate(lams) if abs(x-l)<1e-9][0]
    s = sweeps['e-ölçekleme (taban)']; print(f'  aday λ={l}: φ={s["mV"][j]:.1f} mV  oran={s["ratio"][j]:.3f}')

print('\nL/D duyarlılığı (e-ölçekleme):')
asp = {}
for LD in (2.5, 5.0, 10.0, 20.0):
    g = mk(LD); r0 = g.phi_top(1.0); ph = np.array([g.phi_top(l) for l in lams])
    k2 = fit(lams, ph/r0); asp[LD] = dict(ref_mV=r0, k2_eff=k2, lam_opt=1/np.sqrt(k2), ratio_max=k2f(1/np.sqrt(k2),k2), ratio_at_3p33=float(ph[list(lams).index(3.33)]/r0))
    print(f'  L/D={LD:5.1f}  φ(1)={r0:6.1f} mV  k²_eff={k2:.3f}  λ_opt={1/np.sqrt(k2):.2f}  maks={k2f(1/np.sqrt(k2),k2):.3f}  oran(λ=3.33)={asp[LD]["ratio_at_3p33"]:.3f}')

print('\nAğ yakınsama (λ=1, L/D=5):')
conv = []
for nxy, nz in [(3,10),(4,14),(6,20),(8,28),(12,40)]:
    g = Geo(1000e-9, nxy, nz); p = g.phi_top(1.0); conv.append((nxy, nz, int((nxy+1)**2*(nz+1)*4), p))
for nxy,nz,dof,p in conv: print(f'  n_xy={nxy:2d} n_z={nz:2d}  dof={dof:6d}  φ_top={p:.3f} mV   fark(en ince)={100*(p-conv[-1][3])/conv[-1][3]:+.3f} %')
ps = [c[3] for c in conv]; 
r = (ps[-2]-ps[-3])/(ps[-1]-ps[-2]) if (ps[-1]-ps[-2]) != 0 else np.nan
print('  ardışık fark oranı (yakınsama göstergesi):', np.round(r,2))
OUT.update(sweeps=sweeps, aspect=asp, convergence=[dict(n_xy=a,n_z=b,dof=c_,phi_mV=p) for a,b,c_,p in conv])
json.dump(OUT, open('../data/results_tables/fem_results.json','w'), indent=1)
