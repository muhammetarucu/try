import numpy as np, pandas as pd, re, json
from scipy.stats import spearmanr, hypergeom
d = pd.read_csv('../data/screening_results_v4.csv')
n_all = len(d); isdop = (d['type'] != 'pristine').values

# --- kesin conformal yarı-genişlikleri CSV'den geri çıkar ---
qG = float(np.median(d['Eg_hi'] - d['Eg_v4']))
qP = float(np.median(np.log(d['d_enh_hi'] / d['d_enh_v4'])))
print(f'q_gap={qG:.4f} eV  q_piezo={qP:.4f} (log)   [rapor: 1.61 / 1.75]')

# --- FoM fonksiyonu (kara cisim, notebook ile aynı) ---
h,c,q,kB = 6.62607015e-34, 2.99792458e8, 1.602176634e-19, 1.380649e-23
l2 = np.linspace(280e-9, 2500e-9, 3000); E2 = h*c/l2/q
flbb = (2*np.pi*c/l2**4)/(np.exp(h*c/(l2*kB*5778.0))-1)
Egrid = np.arange(0.0, 8.0005, 0.0005)
eta_grid = np.array([np.trapezoid(flbb*(E2>=e), l2) for e in Egrid]) / np.trapezoid(flbb, l2)
eta = lambda Eg: np.interp(Eg, Egrid, eta_grid)
ETA0 = float(eta(3.37))
sig = lambda z: 1/(1+np.exp(-z))
def fom(Eg, den, ECB, EVB):
    m = np.minimum(-ECB, EVB-1.23)
    return den*(eta(Eg)/ETA0)*sig(m/0.1)

Eg0, den0 = d['Eg_v4'].values, d['d_enh_v4'].values
ECB0, EVB0 = d['E_CB_v4'].values, d['E_VB_v4'].values
f_pt = fom(Eg0, den0, ECB0, EVB0)
print('nokta FoM yeniden üretim: max göreli fark =', np.nanmax(np.abs(f_pt - d['FoM_v4'].values)/np.maximum(d['FoM_v4'].values,1e-9)).round(5))

# --- eleman üyelikleri (formülden) ---
def els(f): return {e for e, _ in re.findall(r'([A-Z][a-z]?)([\d.]+)', f.replace('O1','O'))} - {'Zn','O'}
E = [els(f) for f in d['formula']]
allel = sorted(set().union(*E))
has = {e: np.array([e in s for s in E]) & isdop for e in allel}
has['V|Cr'] = has['V'] | has['Cr']; has['Li|Mn'] = has['Li'] | has['Mn']
has['V|Cr|Li|Mn'] = has['V|Cr'] | has['Li|Mn']

def mc(sG, sP, N=500, seed=0, rho_c=0.0, gap=True, piezo=True):
    rng = np.random.default_rng(seed)
    base_rank = pd.Series(f_pt).rank(ascending=False).values
    top_base = set(np.argsort(base_rank)[:15])
    M = np.zeros((N, n_all), bool); rhos = []; ov = []; fs = []
    for k in range(N):
        zg = rng.normal(size=n_all); zp = rng.normal(size=n_all)
        if rho_c > 0:
            zg = np.sqrt(rho_c)*rng.normal() + np.sqrt(1-rho_c)*zg
            zp = np.sqrt(rho_c)*rng.normal() + np.sqrt(1-rho_c)*zp
        e = Eg0 + (sG*zg if gap else 0.0)
        dd = den0*np.exp(sP*zp if piezo else 0.0)
        de = e - Eg0
        f = fom(e, dd, ECB0 - de/2, EVB0 + de/2); fs.append(f)
        r = pd.Series(f).rank(ascending=False).values
        rhos.append(spearmanr(base_rank, r)[0])
        t = set(np.argsort(r)[:15]); M[k, list(t)] = True; ov.append(len(t & top_base))
    return M, np.array(rhos), np.array(ov), np.array(fs)

sG, sP = qG/1.645, qP/1.645
M, rhos, ov, FS = mc(sG, sP)
print(f'\n[YENİDEN ÜRETİM] rho={rhos.mean():.2f} [{np.percentile(rhos,5):.2f},{np.percentile(rhos,95):.2f}]  top15 korunum={ov.mean():.2f}  '
      f'V/Cr={M[:, has["V|Cr"]].sum(1).mean():.2f} (min {M[:, has["V|Cr"]].sum(1).min()})   [rapor: 0.34 | 2.0 | 5.7 (min 2)]')

# --- sayım dağılımları + permütasyon p-değeri ---
freq = M.mean(0)                      # her adayın MC top-15'e giriş sıklığı
rng = np.random.default_rng(1)
idx_dop = np.where(isdop)[0]
def perm_p(mask, nperm=100000):
    K = int(mask.sum()); obs = float(freq[mask].sum())
    null = np.empty(nperm)
    for i in range(0, nperm, 5000):
        P = np.argsort(rng.random((5000, len(idx_dop))), axis=1)[:, :K]
        null[i:i+5000] = freq[idx_dop][P].sum(1)
    return obs, float((np.sum(null >= obs)+1)/(nperm+1)), float(null.mean())
top_pt = np.argsort(pd.Series(f_pt).rank(ascending=False).values)[:15]
rows = []
for g in ['V','Cr','V|Cr','Li','Mn','Li|Mn','V|Cr|Li|Mn'] + [e for e in allel if e not in ('V','Cr','Li','Mn')]:
    m = has[g]; K = int(m.sum()); cnt = M[:, m].sum(1)
    obs, p, nm = perm_p(m)
    pt = int(m[top_pt].sum()); hp = float(hypergeom(isdop.sum(), K, 15).sf(pt-1))
    rows.append(dict(grup=g, K=K, beklenen=round(15*K/isdop.sum(),2), nokta_top15=pt, nokta_p=round(hp,4),
                     MC_ort=round(cnt.mean(),2), MC_sd=round(cnt.std(),2), MC_min=int(cnt.min()), MC_max=int(cnt.max()),
                     MC_perm_p=round(p,4)))
tab = pd.DataFrame(rows); tab.to_csv('../data/results_tables/enrichment_table.csv', index=False)
print('\n', tab.head(7).to_string(index=False))
print('\nen yüksek MC-zenginleşme (MC_ort/beklenen) tekli element/gruplar:')
t2 = tab[~tab.grup.str.contains(r'\|')].assign(oran=lambda t: t.MC_ort/t.beklenen).sort_values('oran', ascending=False)
print(t2[['grup','K','beklenen','nokta_top15','MC_ort','MC_perm_p','oran']].head(8).round(2).to_string(index=False))

# --- MC top-15 ne kadar rastgele? ---
rand_ov = 15*15/isdop.sum()
pair = []
for _ in range(2000):
    a, b = rng.integers(0, len(M), 2)
    if a != b: pair.append((M[a] & M[b]).sum())
print(f'\nMC top-15 ↔ nokta top-15 örtüşme: {ov.mean():.2f}  (rastgele beklenen {rand_ov:.2f});  çekilişler-arası örtüşme: {np.mean(pair):.2f}')
print('MC\'de en sık top-15\'e giren 8 aday (sıklık):')
for i in np.argsort(-freq)[:8]: print(f'  {d.formula[i]:24s} {freq[i]:.2f}   nokta-top15={i in top_pt}')

# --- mekanizma: yalnız-gap / yalnız-piezo / korelasyonlu hata ---
res = {}
for name, kw in [('bağımsız (taban)', {}), ('yalnız gap belirsizliği', dict(piezo=False)),
                 ('yalnız piezo belirsizliği', dict(gap=False)),
                 ('korelasyon ρc=0.5', dict(rho_c=0.5)), ('korelasyon ρc=0.8', dict(rho_c=0.8)),
                 ('korelasyon ρc=0.95', dict(rho_c=0.95))]:
    Mi, ri, oi, _ = mc(sG, sP, N=300, seed=3, **kw)
    res[name] = dict(rho=round(float(ri.mean()),2), top15_korunum=round(float(oi.mean()),2),
                     VCr=round(float(Mi[:, has['V|Cr']].sum(1).mean()),2), LiMn=round(float(Mi[:, has['Li|Mn']].sum(1).mean()),2))
    print(f'{name:28s} {res[name]}')

# --- E[FoM] ve gap-asimetrisi: V/Cr neden MC'de öne çıkıyor? ---
EF = FS.mean(0)
dfm = pd.DataFrame(dict(formula=d.formula, Eg=Eg0, margin=d['margin_v4'], f_pt=f_pt, EFoM=EF, VCr=has['V|Cr'], LiMn=has['Li|Mn']))[isdop]
print('\nort. nokta-FoM / ort. E[FoM]  (V/Cr)   :', dfm[dfm.VCr].f_pt.mean().round(2), '/', dfm[dfm.VCr].EFoM.mean().round(2))
print('ort. nokta-FoM / ort. E[FoM]  (Li|Mn)  :', dfm[dfm.LiMn].f_pt.mean().round(2), '/', dfm[dfm.LiMn].EFoM.mean().round(2))
print('ort. nokta Eg  V/Cr: %.2f   Li|Mn: %.2f   (tümü: %.2f);  ort. margin V/Cr: %+.2f  Li|Mn: %+.2f' %
      (dfm[dfm.VCr].Eg.mean(), dfm[dfm.LiMn].Eg.mean(), dfm.Eg.mean(), dfm[dfm.VCr].margin.mean(), dfm[dfm.LiMn].margin.mean()))
json.dump(dict(qG=qG, qP=qP, replicate=dict(rho=float(rhos.mean()), overlap=float(ov.mean()), VCr=float(M[:,has['V|Cr']].sum(1).mean())),
                mechanism=res, mc_vs_random_overlap=[float(ov.mean()), rand_ov, float(np.mean(pair))]),
          open('../data/results_tables/enrichment_summary.json','w'), indent=1)
np.save('M.npy', M)
