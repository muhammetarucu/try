import numpy as np, scipy.sparse as sp, json, time
from scipy.optimize import curve_fit
from skfem import (MeshHex, Basis, FacetBasis, ElementHex1, ElementVector, BilinearForm, LinearForm, asm, condense, solve)
from skfem.helpers import sym_grad, grad, dot, ddot
EPS0 = 8.8541878128e-12
c11,c12,c13,c33,c44 = 209.7e9,121.1e9,105.1e9,210.9e9,42.5e9; c66 = 0.5*(c11-c12)
Cv = np.array([[c11,c12,c13,0,0,0],[c12,c11,c13,0,0,0],[c13,c13,c33,0,0,0],[0,0,0,c44,0,0],[0,0,0,0,c44,0],[0,0,0,0,0,c66]])
voigt = [(0,0),(1,1),(2,2),(1,2),(0,2),(0,1)]
C4 = np.zeros((3,3,3,3))
for I,(i,j) in enumerate(voigt):
    for J,(k,l) in enumerate(voigt): C4[i,j,k,l]=C4[j,i,k,l]=C4[i,j,l,k]=C4[j,i,l,k]=Cv[I,J]
e_mat = np.zeros((3,6)); e_mat[2,0]=e_mat[2,1]=-0.57; e_mat[2,2]=1.32; e_mat[0,4]=e_mat[1,3]=-0.48
kap0 = np.diag([7.77,7.77,8.91])*EPS0
S = np.linalg.inv(Cv)
Gam = e_mat @ S @ e_mat.T                      # e s e^T  (3x3)
epsT0 = kap0 + Gam                              # serbest-gerilme geçirgenliği
def e3_of(em):
    t = np.zeros((3,3,3))
    for k in range(3):
        for J,(i,j) in enumerate(voigt): t[k,i,j]=t[k,j,i]=em[k,J]
    return t
# --- analitik büyüklükler ---
k2_33 = Gam[2,2]/kap0[2,2]
w = np.linalg.eigvalsh(np.linalg.inv(np.linalg.cholesky(epsT0)) @ Gam @ np.linalg.inv(np.linalg.cholesky(epsT0)).T)
lam_adm = 1/np.sqrt(w.max())
print(f'e s e^T / κ^S (33) = {k2_33:.3f}   k_T² (maks) = {w.max():.3f}   d-ölçekleme için fiziksel sınır λ_adm = {lam_adm:.2f}')

class Geo:
    def __init__(s, L, n_xy, n_z, R=100e-9):
        s.L = L; s.side = R*np.sqrt(np.pi)
        s.mesh = MeshHex.init_tensor(np.linspace(0,s.side,n_xy+1), np.linspace(0,s.side,n_xy+1), np.linspace(0,L,n_z+1))
        s.bu = Basis(s.mesh, ElementVector(ElementHex1())); s.bp = Basis(s.mesh, ElementHex1())
        @BilinearForm
        def stiff(u,v,w): return ddot(sym_grad(v), np.einsum('ijkl,kl...->ij...', C4, sym_grad(u)))
        s.K = asm(stiff, s.bu)
        e3 = e3_of(e_mat)
        @BilinearForm
        def coup(u,q,w): return dot(grad(q), np.einsum('kij,ij...->k...', e3, sym_grad(u)))
        B = asm(coup, s.bu, s.bp)
        s.nu = s.K.shape[0]; s.np_ = s.bp.N
        s.B = B.T if B.shape[0]==s.np_ else B       # (nu x np)
        fb = FacetBasis(s.mesh, s.bu.elem, facets=s.mesh.facets_satisfying(lambda x: x[2] > L*(1-1e-6)))
        @LinearForm
        def trac(v,w): return -1.0e6*v[2]
        s.f = asm(trac, fb)
        s.D = np.concatenate([s.bu.get_dofs(lambda x: x[2] < L*1e-6).all(), s.nu + s.bp.get_dofs(lambda x: x[2] < L*1e-6).all()])
        z = s.bp.doflocs[2]; s.top = np.where(np.abs(z - z.max()) < L*1e-6)[0]
        s.Mcache = {}
    def M(s, kap):
        key = tuple(np.round(kap.ravel()/EPS0, 9))
        if key not in s.Mcache:
            @BilinearForm
            def diel(p,q,w): return dot(grad(q), np.einsum('ij,j...->i...', kap, grad(p)))
            s.Mcache[key] = asm(diel, s.bp)
        return s.Mcache[key]
    def phi_top(s, lam, mode='e', kscale=1.0, cscale=1.0):
        if mode == 'e': kap = kscale*kap0
        else:
            kap = epsT0 - lam**2*Gam
            if np.linalg.eigvalsh(kap).min() <= 0: return np.nan
        A = sp.bmat([[cscale*s.K, lam*s.B],[lam*s.B.T, -s.M(kap)]], format='csr')
        b = np.concatenate([s.f, np.zeros(s.np_)])
        x = solve(*condense(A, b, D=s.D))
        return abs(float(x[s.nu:][s.top].mean()))*1e3          # mV

def mk(LD, nxy=6): return Geo(LD*200e-9, nxy, max(12, int(round(4*LD))))
