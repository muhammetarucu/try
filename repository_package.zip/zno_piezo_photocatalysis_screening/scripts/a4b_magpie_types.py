import numpy as np, pandas as pd, json, warnings; warnings.filterwarnings('ignore')
from pymatgen.core import Composition
from matminer.featurizers.composition import ElementProperty
ep = ElementProperty.from_preset('magpie'); names = ep.feature_labels()
typ = np.array([n.split()[1] for n in names])           # mean, avg_dev, range, minimum, maximum, mode
vec = lambda f: np.array(ep.featurize(Composition(f)), float)
v0 = vec('ZnO'); groups = {'ağırlıklı (mean, avg_dev)': np.isin(typ, ['mean','avg_dev']), 'ağırlıksız (min, max, range, mode)': np.isin(typ, ['minimum','maximum','range','mode'])}
print('stat türleri:', {t:int((typ==t).sum()) for t in sorted(set(typ))})
res = {}
for M in ['V','Cr','Li','Fe','Al','Mn']:
    for gname, msk in groups.items():
        l2 = {}
        for x in (0.002, 0.02, 0.05, 0.25):
            v = vec(f'Zn{1-x:.4f}{M}{x:.4f}O1'); l2[x] = np.linalg.norm((v-v0)[msk])/np.linalg.norm(v0[msk])
        res[(M,gname)] = l2
print('\nZnO\'dan bağıl L2 uzaklık, öznitelik türüne göre')
print(f'{"dopant":6s} {"tür":36s} {"x=0.002":>9s} {"x=0.02":>9s} {"x=0.05":>9s} {"x=0.25":>9s}   oran(0.05/0.02)')
for (M,g),l2 in res.items():
    print(f'{M:6s} {g:36s} {l2[0.002]:9.4f} {l2[0.02]:9.4f} {l2[0.05]:9.4f} {l2[0.25]:9.4f}   {l2[0.05]/l2[0.02]:.2f}')
# istatistiğe göre: kaç öznitelik x'ten bağımsız?
v1, v2 = vec('Zn0.9980V0.0020O1'), vec('Zn0.7500V0.2500O1')
same = np.abs(v1-v2) < 1e-9*np.maximum(1, np.abs(v1))
print(f'\nV için x=0.002 ile x=0.25 arasında AYNI kalan öznitelik: {same.sum()}/{len(v1)}   (ağırlıksızlar: {same[groups["ağırlıksız (min, max, range, mode)"]].mean():.2f}; ağırlıklılar: {same[groups["ağırlıklı (mean, avg_dev)"]].mean():.2f})')
json.dump({f'{M}|{g}': l2 for (M,g),l2 in res.items()}, open('../data/results_tables/magpie_by_type.json','w'), indent=1)
