import numpy as np, pandas as pd, re
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle
from scipy.stats import spearmanr
import pvlib
plt.rcParams.update({'font.size':10,'savefig.dpi':300,'savefig.bbox':'tight'})
OUT = '../figures'
d = pd.read_csv('../data/screening_results_v4.csv'); cand = d[d.type!='pristine'].copy(); Eg0 = float(d[d.type=='pristine'].Eg_v4.iloc[0])

# ---------------- Fig 7: 5 varyantlı sıralama yörüngesi ----------------
h,c,q,kB = 6.62607015e-34, 2.99792458e8, 1.602176634e-19, 1.380649e-23
sp = pvlib.spectrum.get_reference_spectra(); lam = sp.index.values; irr = sp['global'].values; Eph = h*c/(lam*1e-9)/q; phot = irr/(Eph*q)
f_am = lambda Eg: np.trapezoid(phot[Eph>=Eg], lam[Eph>=Eg])/np.trapezoid(phot, lam)
l2 = np.linspace(280e-9,2500e-9,3000); E2 = h*c/l2/q
def f_bb(Eg, T=5778.0):
    f = (2*np.pi*c/l2**4)/(np.exp(h*c/(l2*kB*T))-1); return np.trapezoid(f*(E2>=Eg), l2)/np.trapezoid(f, l2)
sig = lambda z: 1/(1+np.exp(-z))
def fom(kind='bb', s=0.1, T=5778.0):
    sf = cand.Eg_v4.apply(lambda e: f_am(e) if kind=='am' else f_bb(e,T)); e0 = f_am(Eg0) if kind=='am' else f_bb(Eg0,T)
    return cand.d_enh_v4*(sf/e0)*sig(cand.margin_v4/s)
V = {'baseline\n(blackbody,\n$s$ = 0.1 V)': fom(), 'AM1.5G\nspectrum': fom('am'), '$s$ = 0.05 V': fom(s=0.05), '$s$ = 0.20 V': fom(s=0.20), '$T$ = 5250 K': fom(T=5250.), '$T$ = 6250 K': fom(T=6250.)}
rk = pd.DataFrame({k: v.rank(ascending=False) for k, v in V.items()}); top = V[list(V)[0]].nlargest(15).index
lab = lambda r: f"{r['dopant']} $x$={r['x']:.2f}"
fig, ax = plt.subplots(figsize=(8.8,5.6)); cm = plt.cm.viridis(np.linspace(0.05,0.9,15))
for ci, idx in enumerate(top):
    rr = rk.loc[idx].values; ax.plot(range(len(V)), rr, 'o-', ms=5, lw=1.6, color=cm[ci], alpha=0.9); ax.text(-0.15, rr[0], lab(cand.loc[idx]), ha='right', va='center', fontsize=8, color=cm[ci])
ax.set_xticks(range(len(V))); ax.set_xticklabels(list(V), fontsize=8.5); ax.set_ylabel('FoM rank (point estimate)'); ax.set_ylim(20.5,0.3); ax.set_yticks([1,5,10,15,20])
ax.axhspan(0.3,15.5,color='green',alpha=0.05); ax.text(len(V)-0.6,15.1,'top-15 band',fontsize=8,color='green',ha='right',va='bottom'); ax.grid(axis='y',alpha=0.25); ax.set_xlim(-2.3,len(V)-0.5)
for s in ['top','right','left']: ax.spines[s].set_visible(False)
plt.tight_layout(); plt.savefig(f'{OUT}/Fig7_FoM_sensitivity.png'); plt.close(); print('Fig7 ok')

# ---------------- Fig 11: V serisi (v4 etiketi yok) ----------------
v = cand[(cand.type=='single')&(cand.dopant=='V')].sort_values('x')
fig, ax = plt.subplots(figsize=(7.6,5.0)); ax.axvspan(2.5,26,color='gray',alpha=0.12)
ax.text(0.97,0.97,'beyond reported solubility optimum',transform=ax.transAxes,ha='right',va='top',fontsize=8.5,style='italic',color='gray')
ax.fill_between(v.x*100, v.d_enh_lo, v.d_enh_hi, color='#2a9d8f', alpha=0.15)
l1 = ax.errorbar(v.x*100, v.d_enh_v4, fmt='s-', color='#2a9d8f', ms=6, label='ML-predicted enhancement (90% conformal band)')
ax.set_xlabel('V concentration (at.%)'); ax.set_ylabel('ML-predicted $d_{ij}$ enhancement (×)', color='#2a9d8f'); ax.tick_params(axis='y', colors='#2a9d8f')
ax2 = ax.twinx(); l2_ = ax2.plot([0,1.5,2.5],[11.8,56.0,110.0],'s--',color='#b23a48',ms=7,label='Experimental $d_{33}$ (Yang et al.)')
ax2.set_ylabel('Experimental $d_{33}$ (pC/N)', color='#b23a48'); ax2.tick_params(axis='y', colors='#b23a48'); ax.set_xlim(-0.8,26)
ax.legend([l1,l2_[0]], [l1.get_label(), l2_[0].get_label()], loc='upper right', fontsize=8); plt.tight_layout(); plt.savefig(f'{OUT}/Fig11_ML_vs_experiment.png'); plt.close(); print('Fig11 ok')

# ---------------- Fig 1: güncel boru hattı ----------------
NAVY='#16324f'; BLUE='#1f6fb4'; TEAL='#2a9d8f'; ORANGE='#e9902f'; RED='#b23a48'; PURPLE='#6a4c93'; INK='#1a1a2e'
def card(ax,x,y,w,h,hc,title,badge=None):
    ax.add_patch(FancyBboxPatch((x+0.35,y-0.35),w,h,boxstyle='round,pad=0.25',fc='#000',ec='none',alpha=0.10,zorder=1))
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25',fc='white',ec='#c8cdd4',lw=1.0,zorder=2))
    ax.add_patch(FancyBboxPatch((x,y+h-2.6),w,2.6,boxstyle='round,pad=0.25',fc=hc,ec='none',zorder=3)); ax.add_patch(Rectangle((x-0.25,y+h-2.6),w+0.5,1.4,fc=hc,ec='none',zorder=3))
    ax.text(x+w/2,y+h-1.25,title,ha='center',va='center',fontsize=9.3,fontweight='bold',color='white',zorder=5)
    if badge: ax.add_patch(Circle((x+0.1,y+h+0.15),1.15,fc=INK,ec='white',lw=1.4,zorder=6)); ax.text(x+0.1,y+h+0.15,badge,ha='center',va='center',fontsize=10,fontweight='bold',color='white',zorder=7)
def body(ax,x,y,w,h,lines,fs=8.2): ax.text(x+w/2,y+(h-2.6)/2,'\n'.join(lines),ha='center',va='center',fontsize=fs,color=INK,zorder=5,linespacing=1.45)
def arr(ax,x1,y1,x2,y2,rad=0.0,lw=2.0): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=16,lw=lw,color=INK,connectionstyle=f'arc3,rad={rad}',zorder=4))
fig, ax = plt.subplots(figsize=(12.4,4.9)); ax.set_xlim(0,104); ax.set_ylim(-1,46); ax.axis('off')
W,H,Y = 17.5,15.5,27; xs = [1.5,22,42.5,63,83.5]
card(ax,xs[0],Y,W,H,BLUE,'JARVIS-DFT DATA','1'); body(ax,xs[0],Y,W,H,['dft_3d: 93,902 entries','TBmBJ gaps: 21,559','DFPT piezo: 3,019'])
card(ax,xs[1],Y,W,H,BLUE,'DESCRIPTORS','2'); body(ax,xs[1],Y,W,H,['132 Magpie features','composition-only','(matminer)'])
card(ax,xs[2],Y,W,H,TEAL,'UQ ENSEMBLES','3'); body(ax,xs[2],Y,W,H,['5$\\times$ XGBoost / target','grouped MAE 0.57 eV','split-conformal 90%'])
card(ax,xs[3],Y,W,H,TEAL,'SCISSOR ANCHOR','4'); body(ax,xs[3],Y,W,H,['$\\Delta$ = +1.35 eV','(0.90 functional','+ 0.45 surrogate)'])
card(ax,xs[4],Y,W,H,ORANGE,'CANDIDATES','5'); body(ax,xs[4],Y,W,H,['95 singly doped','198 co-doped','Zn$_{1-x}$M$_x$O'])
for a,b in [(18,21),(38,41),(60,63),(79,82)]: arr(ax,a+0.35,Y+H/2,b-0.45,Y+H/2)
Y2 = 2.5
card(ax,33.5,Y2,24,H,ORANGE,'SCREENING','6'); body(ax,33.5,Y2,24,H,['solar-weighted FoM','conformal Monte-Carlo + AD check','resolution tests (grid, lookup, KRR)'],fs=8.0)
card(ax,4,Y2,23,H,RED,'DFT SPOT CHECK'); body(ax,4,Y2,23,H,['Quantum ESPRESSO (PBE)','$e_{33}^{(0)}=-0.74$ C/m$^2$','ZnO PBE gap 0.82 eV'])
card(ax,63,Y2,26,H,PURPLE,'DEVICE-LEVEL FEM'); body(ax,63,Y2,26,H,['scikit-fem $\\leftrightarrow$ SfePy (0.15%)','$\\phi_{top}(\\lambda)$: optimum near 1.9$\\times$','conditional on tensor scaling'])
arr(ax,92,Y-0.4,51,Y2+H+0.9,rad=-0.28,lw=2.4); arr(ax,33.0,Y2+H/2-1.3,28.9,Y2+H/2-1.3,lw=2.2); arr(ax,58.0,Y2+H/2-1.3,62.1,Y2+H/2-1.3,lw=2.2)
for xx,t in [(31.0,'compare'),(60.0,'translate')]: ax.text(xx,Y2+H/2-1.3,t,fontsize=7.2,style='italic',ha='center',va='center',zorder=6,bbox=dict(boxstyle='round,pad=0.18',fc='white',ec='#c8cdd4',lw=0.8))
plt.savefig(f'{OUT}/Fig1_pipeline.png', facecolor='white'); plt.close(); print('Fig1 ok')
