import numpy as np, pandas as pd, json, warnings; warnings.filterwarnings('ignore')
from pymatgen.core import Composition
from matminer.featurizers.composition import ElementProperty
out = {}
# --- (12-ii) Ce: Butler–Ginley'de χ_Ce belirsizliğinin bant kenarı etkisi ---
chi = {'Zn':4.45,'O':7.54}
def chi_mean(x, chi_d): return ((chi['Zn']**(1-x))*(chi_d**x)*chi['O'])**0.5
print('Ce: χ_Ce 2.5→4.5 eV değişiminin E_CB (Butler–Ginley) üzerindeki en büyük etkisi')
ce = {}
for x in (0.02,0.05,0.10,0.15,0.25):
    span = chi_mean(x,4.5)-chi_mean(x,2.5); ce[x]=span; print(f'  x={x:.2f}: ΔE_CB(aralık) = {span:.3f} eV')
out['Ce_chi_span_eV'] = ce
# --- (3) Magpie: seyreltik katkıda öznitelik vektörü ne kadar oynuyor? ---
ep = ElementProperty.from_preset('magpie'); names = ep.feature_labels()
def vec(f): return np.array(ep.featurize(Composition(f)), float)
v0 = vec('ZnO')
dop = ['V','Cr','Li','Fe','Al','Mn','Cu','Ni','Co','Y','La','Na']
rows = []; V = {}
for x in (0.002, 0.02, 0.05, 0.10, 0.25):
    for M in dop:
        v = vec(f'Zn{1-x:.4f}{M}{x:.4f}O1'); V[(M,x)] = v
        nz = np.abs(v0) > 1e-9
        rel = np.abs(v-v0)[nz]/np.abs(v0)[nz]
        rows.append(dict(M=M, x=x, frac_changed=float(np.mean(np.abs(v-v0)>1e-9)), med_rel=float(np.median(rel)),
                         max_rel=float(rel.max()), l2_rel=float(np.linalg.norm(v-v0)/np.linalg.norm(v0))))
T = pd.DataFrame(rows)
print('\nMagpie öznitelik vektörü, ZnO\'dan bağıl L2 uzaklık (‖Δf‖/‖f‖) — seyreltik katkı:')
print(T.pivot(index='M', columns='x', values='l2_rel').loc[dop].round(4).to_string())
t2 = T[T.x==0.02]
print(f'\nx=0.02: değişen öznitelik oranı {t2.frac_changed.mean():.2f};  öznitelik başına medyan bağıl değişim {t2.med_rel.median():.4f} ;  en büyük tekil öznitelik değişimi (medyan dopantlar): {t2.max_rel.median():.3f}')
d2 = np.array([np.linalg.norm(V[(a,0.02)]-V[(b,0.02)])/np.linalg.norm(v0) for a in dop for b in dop if a<b])
print(f'x=0.02 dopantlar-arası bağıl uzaklık: medyan {np.median(d2):.4f}, maks {d2.max():.4f}   (ZnO→dopant medyan {t2.l2_rel.median():.4f})')
out['magpie_l2_rel_x002'] = {r.M: r.l2_rel for r in t2.itertuples()}
out['magpie_dopant_to_dopant_median'] = float(np.median(d2))
T.to_csv('../data/results_tables/magpie_dilute_distance.csv', index=False)
json.dump(out, open('../data/results_tables/misc_results.json','w'), indent=1)
