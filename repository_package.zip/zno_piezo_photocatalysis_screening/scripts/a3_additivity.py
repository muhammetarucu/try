import numpy as np, pandas as pd, re, json
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.stats import spearmanr
plt.rcParams.update({'font.size':10,'savefig.dpi':300,'savefig.bbox':'tight'})
d = pd.read_csv('../data/screening_results_v4.csv')
Eg0 = float(d[d.type=='pristine'].Eg_v4.iloc[0])
h,c,q,kB = 6.62607015e-34, 2.99792458e8, 1.602176634e-19, 1.380649e-23
l2 = np.linspace(280e-9, 2500e-9, 3000); E2 = h*c/l2/q
flbb = (2*np.pi*c/l2**4)/(np.exp(h*c/(l2*kB*5778.0))-1)
Eg_ = np.arange(0,8.0005,0.0005); eg_ = np.array([np.trapezoid(flbb*(E2>=e), l2) for e in Eg_])/np.trapezoid(flbb,l2)
eta = lambda e: np.interp(e, Eg_, eg_); ETA0 = float(eta(3.37)); sig = lambda z: 1/(1+np.exp(-z))
fom = lambda Eg, den, cb, vb: den*(eta(Eg)/ETA0)*sig(np.minimum(-cb, vb-1.23)/0.1)
def parse(f): return [(e,float(n)) for e,n in re.findall(r'([A-Z][a-z]?)([\d.]+)', f.replace('O1','O')) if e not in('Zn','O')]
sing = {(r.dopant, round(r.x,2)): r for r in d[d.type=='single'].itertuples()}
rows=[]
for r in d[d.type=='co'].itertuples():
    (a,xa),(b,xb) = parse(r.formula); sa, sb = sing[(a,round(xa,2))], sing[(b,round(xb,2))]
    dA, dB = sa.d_enh_v4, sb.d_enh_v4; gA, gB = sa.Eg_v4-Eg0, sb.Eg_v4-Eg0
    Egadd = Eg0+gA+gB
    cb = r.E_CB_v4 - (Egadd-r.Eg_v4)/2; vb = r.E_VB_v4 + (Egadd-r.Eg_v4)/2
    rows.append(dict(f=r.formula, pair=r.dopant, d=r.d_enh_v4, dA=dA, dB=dB, g=r.Eg_v4-Eg0, gA=gA, gB=gB, fom=r.FoM_v4,
                     d_prod=dA*dB, d_mean=(dA+dB)/2, d_max=max(dA,dB), d_geo=np.sqrt(dA*dB), d_inc=1+(dA-1)+(dB-1),
                     g_add=gA+gB, fom_add=float(fom(Egadd, dA*dB, cb, vb))))
T = pd.DataFrame(rows)
print(f'ko-katkılı satır: {len(T)}')
R = {}
for name,col in [('çarpım dA·dB','d_prod'),('geometrik ort.','d_geo'),('aritmetik ort.','d_mean'),('maks(dA,dB)','d_max'),('artımsal 1+(dA−1)+(dB−1)','d_inc')]:
    rho = spearmanr(T.d, T[col])[0]; r2 = np.corrcoef(np.log(T.d), np.log(T[col].clip(lower=1e-3)))[0,1]**2
    R[name] = (rho, r2); print(f'  d_enh_ko ~ {name:26s} Spearman={rho:.2f}  log-log R²={r2:.2f}')
rho_g = spearmanr(T.g, T.g_add)[0]; print(f'  ΔEg_ko ~ ΔEg_A+ΔEg_B           Spearman={rho_g:.2f}  R²={np.corrcoef(T.g,T.g_add)[0,1]**2:.2f}  RMS fark={np.sqrt(np.mean((T.g-T.g_add)**2)):.3f} eV')
rho_f = spearmanr(T.fom, T.fom_add)[0]; print(f'  FoM_ko ~ FoM(toplamsal d,Eg)   Spearman={rho_f:.2f}')
X = np.c_[np.ones(len(T)), np.log(T.dA), np.log(T.dB)]; beta,*_ = np.linalg.lstsq(X, np.log(T.d), rcond=None)
pred = X@beta; r2 = 1-np.sum((np.log(T.d)-pred)**2)/np.sum((np.log(T.d)-np.log(T.d).mean())**2)
print(f'  log d_ko = {beta[0]:.2f} + {beta[1]:.2f} log dA + {beta[2]:.2f} log dB   (R²={r2:.2f})')
top_co = set(T.sort_values('fom', ascending=False).head(15).index); top_add = set(T.sort_values('fom_add', ascending=False).head(15).index)
print(f'  ko-katkı top-15 ↔ toplamsal-tahmin top-15 örtüşme: {len(top_co & top_add)}/15')
within = np.mean(np.abs(np.log(T.d/T.d_prod)) < np.log(1.25)); print(f'  d_ko, dA·dB\'nin ×1.25 içinde: %{100*within:.0f}')
json.dump(dict(spearman_d_prod=R['çarpım dA·dB'][0], r2_d_prod=R['çarpım dA·dB'][1], spearman_gap=float(rho_g), spearman_fom=float(rho_f),
               beta=beta.tolist(), r2_reg=float(r2), top15_overlap=len(top_co&top_add), within125=float(within), all=R), open('../data/results_tables/additivity.json','w'), indent=1)
fig, ax = plt.subplots(1,3, figsize=(12.6,4.1))
for a,(x,y,xl,yl,log) in zip(ax, [(T.d_prod,T.d,'$d_{enh}^{A}\\times d_{enh}^{B}$ (single-dopant predictions)','$d_{enh}$ of co-doped composition',True),
                                   (T.g_add,T.g,'$\\Delta E_g^{A}+\\Delta E_g^{B}$ (eV)','$\\Delta E_g$ of co-doped composition (eV)',False),
                                   (T.fom_add,T.fom,'FoM from additive $d_{enh}$, $E_g$','FoM of co-doped composition',True)]):
    a.scatter(x, y, s=16, alpha=0.6, color='#6a4c93', edgecolor='none')
    lo, hi = min(x.min(),y.min()), max(x.max(),y.max()); lo = max(lo,1e-2) if log else lo
    a.plot([lo,hi],[lo,hi],'r--',lw=1)
    if log: a.set_xscale('log'); a.set_yscale('log')
    a.set_xlabel(xl, fontsize=9); a.set_ylabel(yl, fontsize=9)
ax[0].set_title(f'(a) Spearman $\\rho$ = {R["çarpım dA·dB"][0]:.2f}', fontsize=10); ax[1].set_title(f'(b) Spearman $\\rho$ = {rho_g:.2f}', fontsize=10); ax[2].set_title(f'(c) Spearman $\\rho$ = {rho_f:.2f}', fontsize=10)
plt.tight_layout(); plt.savefig('../data/results_tables/Fig_additivity.png'); print('Fig_additivity.png kaydedildi')
