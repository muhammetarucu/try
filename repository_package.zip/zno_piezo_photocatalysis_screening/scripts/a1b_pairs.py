import numpy as np, pandas as pd, re, itertools, json
d = pd.read_csv('../data/screening_results_v4.csv')
M = np.load('M.npy'); freq = M.mean(0)
isdop = (d['type']!='pristine').values
def els(f): return {e for e,_ in re.findall(r'([A-Z][a-z]?)([\d.]+)', f.replace('O1','O'))} - {'Zn','O'}
E = [els(f) for f in d['formula']]
cat12 = ['V','Cr','Fe','Li','Na','Mg','Al','Ga','Co','Ni','Cu','Mn']       # ko-katkı kümesi (hem tekli hem ko-katkıda var)
top_pt = np.argsort(pd.Series(d['FoM_v4'].values).rank(ascending=False).values)[:15]

def stats(group):
    m = np.array([bool(group & s) for s in E]) & isdop
    return int(m[top_pt].sum()), float(freq[m].sum()), int(m.sum())
rows = []
for a,b in itertools.combinations(cat12, 2):
    pt, mc, K = stats({a,b}); rows.append((a+'+'+b, K, pt, mc))
P = pd.DataFrame(rows, columns=['cift','K','nokta_top15','MC_ort'])
P['beklenen'] = 15*P.K/isdop.sum()
P['MC_oran'] = P.MC_ort/P.beklenen
P['rank_nokta'] = P.nokta_top15.rank(ascending=False, method='min').astype(int)
P['rank_MC'] = P.MC_ort.rank(ascending=False, method='min').astype(int)
P.to_csv('../data/results_tables/element_pair_table.csv', index=False)
print('66 element çifti arasında sıralama (1 = en zenginleşmiş):')
for pr in ['V+Cr','Li+Mn','Cr+Li','Cr+Mn','V+Li']:
    r = P[P.cift==pr].iloc[0]
    print(f'  {pr:6s} nokta {int(r.nokta_top15):2d}/15 (sıra {r.rank_nokta}/66)   MC {r.MC_ort:.2f} (sıra {r.rank_MC}/66)   beklenen {r.beklenen:.2f}   → seçim-sonrası p = {r.rank_MC/66:.2f}')
print('\nMC-ortalamaya göre en zengin 6 çift:'); print(P.sort_values('MC_ort', ascending=False).head(6)[['cift','K','nokta_top15','MC_ort','beklenen']].round(2).to_string(index=False))
print('\nnokta-tahmine göre en zengin 6 çift:'); print(P.sort_values('nokta_top15', ascending=False).head(6)[['cift','K','nokta_top15','MC_ort','beklenen']].round(2).to_string(index=False))

# tek element sıralaması (12 element içinde)
S = []
for e in cat12:
    pt, mc, K = stats({e}); S.append((e, K, pt, mc, 15*K/isdop.sum()))
S = pd.DataFrame(S, columns=['el','K','nokta','MC','bekl']); S['MC_oran']=S.MC/S.bekl
print('\ntek element (12 ko-katkı kümesi):'); print(S.sort_values('MC_oran', ascending=False).round(2).to_string(index=False))

# --- yalnız dilüt alt küme (her katkı ≤ %5): yeniden sırala ---
def xs(f): return [float(n) for e,n in re.findall(r'([A-Z][a-z]?)([\d.]+)', f.replace('O1','O')) if e not in ('Zn','O')]
dil = np.array([isdop[i] and max(xs(f)) <= 0.05+1e-9 for i,f in enumerate(d['formula'])])
print(f'\ndilüt alt küme: {dil.sum()}/{isdop.sum()} aday')
fp = d['FoM_v4'].values.copy(); fp[~dil] = -np.inf
top_d = np.argsort(-fp)[:15]
print('dilüt nokta-top15 formülleri:', [d.formula[i].replace('O1','').replace('Zn','') for i in top_d[:15]])
for g in ['V','Cr','Li','Mn','Fe']:
    m = np.array([g in s for s in E]) & dil
    print(f'  {g:2s}: dilüt aday {m.sum():3d}  nokta dilüt-top15 içinde {int(m[top_d].sum()):2d}  (beklenen {15*m.sum()/dil.sum():.2f})')
