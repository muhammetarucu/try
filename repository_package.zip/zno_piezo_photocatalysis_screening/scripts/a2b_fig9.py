import numpy as np, json
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from fem_core import *
plt.rcParams.update({'font.size':10,'savefig.dpi':300,'savefig.bbox':'tight'})
k2f = lambda lam, k2: lam*(1+k2)/(1+lam**2*k2)
R = json.load(open('../data/results_tables/fem_results.json'))
sw = R['sweeps']; base = sw['e-ölçekleme (taban)']; lam = np.array(base['lam'])
k2 = base['k2_eff']
# (a) alan kesiti
g = Geo(1000e-9, 8, 28)
A = sp.bmat([[g.K, g.B],[g.B.T, -g.M(kap0)]], format='csr'); b = np.concatenate([g.f, np.zeros(g.np_)])
x = solve(*condense(A, b, D=g.D)); phi = x[g.nu:]; co = g.bp.doflocs
xc = co[0][np.argmin(np.abs(co[0]-g.side/2))]; m = np.abs(co[0]-xc) < g.side*1e-4
Y,Z,P = co[1][m], co[2][m], np.abs(phi[m])*1e3; ny = len(np.unique(np.round(Y/g.side,9))); o = np.lexsort((Y,Z))
Yg,Zg,Pg = Y[o].reshape(-1,ny), Z[o].reshape(-1,ny), P[o].reshape(-1,ny)
# (b) L/D
LDs = [2.5,5,10,15,20]; phLD = [mk(v).phi_top(1.0) for v in LDs]
fig, (a1,a2,a3) = plt.subplots(1,3, figsize=(13.8,4.2), gridspec_kw={'width_ratios':[0.8,0.95,1.35]})
pc = a1.pcolormesh(Yg*1e9, Zg*1e9, Pg, cmap='plasma', shading='gouraud'); cb = plt.colorbar(pc, ax=a1, pad=0.02); cb.set_label('$|\\phi|$ (mV)', fontsize=9)
a1.set_xlabel('y (nm)'); a1.set_ylabel('z (nm)'); a1.set_aspect(0.35)
a1.annotate('', xy=(Yg.max()*1e9/2, 985), xytext=(Yg.max()*1e9/2, 1105), arrowprops=dict(arrowstyle='-|>', lw=2, color='k')); a1.text(Yg.max()*1e9/2+12, 1050, '1 MPa', fontsize=8.5)
a1.text(0.03,0.97,'(a)',transform=a1.transAxes,fontsize=13,fontweight='bold',va='top',color='white')
a2.plot(LDs, phLD, 'o-', c='#1f6fb4', ms=6.5); a2.set_xlabel('Aspect ratio $L/D$'); a2.set_ylabel('Top piezopotential $|\\phi_{top}|$ (mV)'); a2.grid(alpha=0.3)
a2.text(0.03,0.97,'(b)',transform=a2.transAxes,fontsize=13,fontweight='bold',va='top')
# (c) λ-taraması
ll = np.linspace(1,5,200)
lo = np.array(sw['e-ölçekleme κ×1.3']['ratio']); hi = np.array(sw['e-ölçekleme κ×0.7']['ratio'])
a3.fill_between(lam, np.minimum(lo,hi), np.maximum(lo,hi), color='#2a9d8f', alpha=0.18, label='$\\kappa^S\\times$0.7 to $\\times$1.3 ($e$ scaled)')
a3.plot(ll, k2f(ll,k2), '-', c='k', lw=1.4, label=f'1-D expression, $k^2_{{eff}}$ = {k2:.2f}')
a3.plot(lam, base['ratio'], 'o', c='#c0532f', ms=5, label='FEM, $e$ scaled ($\\kappa^S$, $c$ fixed)')
dd = sw['d-ölçekleme (ε^T,c sabit)']; ok = np.array(dd['lam']) <= R['lambda_admissible_dscaling']
a3.plot(np.array(dd['lam'])[ok], np.array(dd['ratio'])[ok], 's--', c='#6a4c93', ms=4.5, label='FEM, $d$ scaled at fixed $\\varepsilon^T$, $c$')
a3.axvspan(R['lambda_admissible_dscaling'], 5, color='gray', alpha=0.12); a3.text(3.6, 2.15, 'fixed-$\\varepsilon^T$ scaling\nnot admissible\n($\\kappa^S<0$)', fontsize=8, color='gray', ha='center')
a3.axvline(1/np.sqrt(k2), ls=':', c='k', lw=1); a3.text(1/np.sqrt(k2)+0.05, 0.86, f'$\\lambda_{{opt}}$ = {1/np.sqrt(k2):.2f}', fontsize=8.5)
for l_ in (2.98,3.21,3.33):
    j = list(lam).index(l_); a3.plot(lam[j], base['ratio'][j], 'D', c='gold', mec='k', ms=7, zorder=5)
a3.text(3.55, 1.20, 'ML-predicted\n$d_{enh}$ of the\nTable 2 compositions', fontsize=8, ha='left')
a3.set_xlim(1,5); a3.set_ylim(0.8,2.35); a3.set_xlabel('Material-level enhancement $\\lambda$ (tensor scale factor)'); a3.set_ylabel('$\\phi_{top}(\\lambda)/\\phi_{top}(1)$')
a3.legend(fontsize=7.3, loc='upper left', framealpha=0.95); a3.grid(alpha=0.25)
a3.text(0.03,0.04,'(c)',transform=a3.transAxes,fontsize=13,fontweight='bold',ha='left')
plt.tight_layout(); plt.savefig('../data/results_tables/Fig9_FEM_candidates_combined.png'); print('Fig9 kaydedildi; L/D φ:', np.round(phLD,1))
